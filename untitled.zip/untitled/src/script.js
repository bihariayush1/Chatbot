// Function to scroll chatbox to the bottom after each message
function scrollToBottom() {
  const chatBox = document.getElementById('chat-box');
  chatBox.scrollTop = chatBox.scrollHeight;
}

// Function to display a message in the chat
function displayMessage(message, sender) {
  const chatBox = document.getElementById('chat-box');
  const messageElement = document.createElement('div');
  messageElement.classList.add('message', sender);
  messageElement.innerText = message;
  chatBox.appendChild(messageElement);
  scrollToBottom();
}

// Handle sending user messages
document.getElementById('send-btn').addEventListener('click', function () {
  const userMessage = document.getElementById('user-input').value.trim();
  
  if (userMessage) {
    // Display the user message
    displayMessage(userMessage, 'user-msg');
    
    // Clear the input field
    document.getElementById('user-input').value = '';
    
    // Display typing indicator for the bot
    displayMessage("Typing...", 'bot-msg');
    
    setTimeout(() => {
      // Remove typing indicator
      const chatBox = document.getElementById('chat-box');
      chatBox.lastChild.remove();
      
      // Get bot's response
      const botReply = getBotResponse(userMessage);
      displayMessage(botReply, 'bot-msg');
    }, 1500);  // Simulate a 1.5s delay for bot response
  }
});

// Handle pressing 'Enter' to send messages
document.getElementById('user-input').addEventListener('keypress', function (e) {
  if (e.key === 'Enter') {
    document.getElementById('send-btn').click();
  }
});

// Define responses for common queries
function getBotResponse(message) {
  const responses = {
    "hello": "Hello! How can I assist you today?",
    "hi": "Hi there! What can I help you with?",
    "how are you": "I'm doing great, thank you for asking!",
    "bye": "Goodbye! Have a nice day!",
    "help": "You can ask me about services, product details, or anything related to our website.",
    "who are you": "I'm a virtual assistant here to provide information and help you out!",
    "what is your name": "I don't have a personal name, but you can call me Assistant!",
    "what is the weather": "I am unable to fetch weather info right now, but try checking a weather website or app.",
  };

  message = message.toLowerCase();
  if (responses[message]) {
    return responses[message];
  } else if (message.includes("what is") || message.includes("who is")) {
    return fetchWikipediaData(message);
  } else {
    return "Sorry, I didn't understand that. Can you please rephrase?";
  }
}

// Fetch Wikipedia data for specific queries
function fetchWikipediaData(query) {
  const url = `https://en.wikipedia.org/w/api.php?action=opensearch&search=${query}&limit=1&format=json`;

  fetch(url)
    .then(response => response.json())
    .then(data => {
      const result = data[1][0];
      if (result) {
        return `Here's what I found: ${result}`;
      } else {
        return "Sorry, I couldn't find any information on that topic.";
      }
    })
    .catch(error => {
      console.error("Error fetching data:", error);
      return "Sorry, I couldn't fetch that information.";
    });
}